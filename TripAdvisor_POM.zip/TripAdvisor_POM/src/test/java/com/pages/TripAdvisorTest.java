package com.pages;

import org.testng.annotations.Test;

public class TripAdvisorTest extends BaseTest {

	BaseTest baseTest;
	TripAdvisorSearchClick search;
	
	@Test
	public void test() throws InterruptedException {
		
		baseTest=new BaseTest();
		baseTest.initialization();
		
		search=new TripAdvisorSearchClick();
		search.TripAdvisorSearchClickk();
		search.Search();
		search.searchButton();
		search.clickHotel();
		search.clickWriteReview();
		search.SubmitReview();
		search.ReviewTitle();
		search.ReviewText();
		search.selectPurpose();
		search.selectWhen();
		search.clickCheckBox();
		search.reviewSubmit();
		
		
		
		baseTest.tearDown();
		
	}
	
}
