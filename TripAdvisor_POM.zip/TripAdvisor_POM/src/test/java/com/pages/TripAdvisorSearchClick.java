package com.pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class TripAdvisorSearchClick extends BaseTest {


	@FindBy(xpath="/html/body/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div/div[5]/div")
	WebElement searchClick;
	
	@FindBy(id="mainSearch")
	WebElement search;
	
	@FindBy(id="SEARCH_BUTTON")
    WebElement searchButton;	
	
	@FindBy(xpath="//*[@id=\"BODY_BLOCK_JQUERY_REFLOW\"]/div[2]/div/div[2]/div/div/div/div/div[1]/div/div[1]/div/div[3]/div/div[1]/div/div[2]/div/div/div/div/div/div/div[2]/div[1]/div[1]/span")
	WebElement clickHotel;
	
	@FindBy(xpath="//*[@id=\"component_12\"]/div/div[2]/div/div[2]/div/div[1]/a")
	WebElement clickWriteReview;
	
	@FindBy(linkText="Write a review")
	WebElement ClickWriteReview;
	
	@FindBy(xpath="/html/body/div[4]/div[2]/div/div/form/div[1]/div/fieldset[1]/div[2]/div/div/div[1]/div[2]/div[2]/span")
	WebElement SubmitReview;
	
	@FindBy(id="ReviewTitle")
	WebElement ReviewTitlee;
	
	@FindBy(id="ReviewText")
	WebElement ReviewTextt;
	
	@FindBy(xpath="//*[@id=\"trip_type_table\"]/div[5]")
	WebElement selectPurpose;
	
	@FindBy(id="trip_date_month_year")
	WebElement selectWhen;
	
	@FindBy(id="noFraud")
	WebElement clickCheckBox;
	
	@FindBy(xpath="//*[@id='SUBMIT']/span")
	WebElement reviewSubmit;
	
	public TripAdvisorSearchClick() {
		PageFactory.initElements(driver, this);
	}
	
	public void TripAdvisorSearchClickk() throws InterruptedException {
		
		Thread.sleep(3000);
		
	 searchClick.click();
	 Thread.sleep(3000);
	}
	
	public void Search() throws InterruptedException 
	{
		Thread.sleep(3000);
		search.sendKeys("Club Mahindra");
	}
	
	public void searchButton() throws InterruptedException 
	{
		Thread.sleep(3000);
		searchButton.click();
	}
	
	public void clickHotel() throws InterruptedException 
	{
	
		Thread.sleep(3000);
		clickHotel.click();
		Thread.sleep(5000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(0));
	    driver.close();
	    driver.switchTo().window(tabs2.get(1));
		String data=driver.getTitle();
		System.out.println(data);
	}
		public void clickWriteReview() throws InterruptedException {
			//driver.switchTo().frame("google_osd_static_frame_762369984261");
			//JavascriptExecutor jse1=(JavascriptExecutor) driver;
			//jse.executeScript("windown.scrollBy(0,1000)");
			JavascriptExecutor jse=(JavascriptExecutor) driver;
			 //jse.executeScript("window.scrollBy(0,1000)","");
			//WebElement flag=driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div[7]/div/div[1]/div[1]/div/div/div[2]/div/div[2]/div/div[1]/a"));
			//Thread.sleep(2000);
			//jse.executeScript("arguments[0].scrollIntoView();", flag);
			 Thread.sleep(5000);
			jse.executeScript("window.scrollBy(0,3000)");
			// flag.click();
			 Thread.sleep(3000);
			 ClickWriteReview.click();
		}
		 
		 
		public void SubmitReview() throws InterruptedException {
			
		 
		 ArrayList<String> tabs3 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs3.get(0));
		    driver.close();
		    driver.switchTo().window(tabs3.get(1));
		
		    Actions actions = new Actions(driver);
		    actions.moveToElement(SubmitReview);
		    actions.click().perform();
		    Thread.sleep(2000);
		   // Select sel=new Select(star);
		   // sel.selectByValue("1");
		}
		    
		
		public void ReviewTitle() throws InterruptedException {
			ReviewTitlee.sendKeys("Nice");
		    Thread.sleep(2000);
		}
		
		
		public void ReviewText() throws InterruptedException {    
			ReviewTextt.sendKeys("Its a huge property surrounded"
		    		+ " by a lot of greenery. We went there for lunch and got to look around "
		    		+ "the property and one of the rooms. It...Its a huge property surrounded "
		    		+ "by a lot of greenery. We went there for lunch and got to look around "
		    		+ "the property and one of the rooms. It...");
			Thread.sleep(2000);
		    JavascriptExecutor jse2=(JavascriptExecutor) driver;
		    jse2.executeScript("window.scrollBy(0,300)");
		    Thread.sleep(2000);

		}
		    public void selectPurpose() throws InterruptedException {
		    selectPurpose.click();
		    Thread.sleep(2000);
		    }
		  //*[@id="trip_type_table"]/div[5]
		    
		    public void selectWhen() throws InterruptedException {
		    WebElement star1 = driver.findElement(By.id("trip_date_month_year"));
		    Select sel1=new Select(star1);
		    sel1.selectByValue("1,2020");
		    
		    JavascriptExecutor jse1=(JavascriptExecutor) driver;
		    jse1.executeScript("window.scrollBy(0,1000)");
		    Thread.sleep(2000);
		    }
		    
		    public void clickCheckBox() throws InterruptedException {

		    Thread.sleep(2000);
		    clickCheckBox.click();
		    }
		    
		    public void reviewSubmit() throws InterruptedException {
		    Thread.sleep(2000);
		    reviewSubmit.click();
		    
		  //*[@id="SUBMIT"]/span
		    
		
		    //WebElement data1=driver.findElement(By.id("bubble_rating"));
		   // Select sel=new Select(data1);
		   // sel.selectByValue("5");
		   // data1.click();
		
	}
	
	/*public void clickWriteReview() throws InterruptedException 
	{
		Thread.sleep(3000);
		clickWriteReview.click();
	}*/
	

}
