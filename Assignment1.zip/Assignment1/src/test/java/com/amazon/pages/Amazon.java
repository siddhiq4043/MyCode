package com.amazon.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Amazon extends TestBase {


	@FindBy(id="twotabsearchtextbox")
	WebElement amazonSearch;
	
	@FindBy(xpath="//*[@id=\'nav-search\']/form/div[2]/div/input")
	WebElement amazonSearchClick;
	
	@FindBy(xpath="//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div/div/a/span[1]/span[2]/span[2]")
	WebElement iphoneSelect;
	
    @FindBy(xpath="/html/body/div[2]/div/div/button")
    WebElement popClose;
	
	@FindBy(name="q")
	WebElement flipkartSearch;
	
	@FindBy(xpath="//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[2]/form/div/button")
	WebElement flipkartSearchClick;
	
	@FindBy(xpath="//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div/div/div")
	WebElement fiphoneSelectPrice;
	
	
	public Amazon() {
		PageFactory.initElements(driver, this);
	}

	public void sendKeys() throws InterruptedException {
		Thread.sleep(2000);
		amazonSearch.sendKeys("iphone xr 64gb yellow");
		Thread.sleep(2000);
	}
	
	public void searchClick() throws InterruptedException {
		amazonSearchClick.click();
		Thread.sleep(2000);
	}
	
	public String iphoneSelect() {
		return iphoneSelect.getText();
	}
	
	public void flipkart() throws InterruptedException {
		driver.get("http://www.flipkart.com");
		Thread.sleep(2000);
	}
	
	public void popClose() throws InterruptedException {
		
		
		popClose.click();
	}
	
	public void flipkartSearch() throws InterruptedException {
		Thread.sleep(1000);
		flipkartSearch.sendKeys("iphone xr 64gb yellow");
	}
	
	public void flipkartSearchClick()
	{
		flipkartSearchClick.click();
	}
	
	
	public String fiphoneSelectPrice()
	{
		return fiphoneSelectPrice.getText();
	}
}
