package com.amazon.test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.amazon.pages.Amazon;
import com.amazon.pages.TestBase;


public class AmazonTest extends TestBase {

	TestBase baseTest;
	Amazon search;

	@Test
	public void test() throws InterruptedException {
		
		baseTest=new TestBase();
		baseTest.initialization();
		
		search=new Amazon();
		search.sendKeys();
		
		search.searchClick();
		
		search.iphoneSelect();
		String amazonPrice=driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div/div/a/span[1]/span[2]/span[2]")).getText();
	    System.out.println("The selected iphone amazon price is:" + amazonPrice);
	
	    search.flipkart();
	    
	    search.popClose();
	    
	    search.flipkartSearch();
	   
	    search.flipkartSearchClick();
	    
		search.fiphoneSelectPrice();
		String flipkartPrice=driver.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div/div/div")).getText();
	    System.out.println("The selected iphone fripkart price is:"+flipkartPrice);
	    
	    int flipkartPrice1=47900;
	    int amazonPrice1=53999;
	    if(flipkartPrice1<amazonPrice1) {
		System.out.println(amazonPrice1 + "greater than"+ flipkartPrice1);
		System.out.println("Flipkart is the lowest price for iPhone -- "+flipkartPrice1);
		
	    baseTest.tearDown();
	    
	
	 }
	
	}
}
